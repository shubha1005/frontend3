import React, { useState, useEffect } from "react";
import { db } from "../firebaseConfig";
import { collection, getDocs, doc, updateDoc } from "firebase/firestore";
import emailjs from "emailjs-com";

const AdminDashboard = () => {
  const [pickupRequests, setPickupRequests] = useState([]);
  const [schoolDrives, setSchoolDrives] = useState([]);

  // Fetch all pickup requests and school drives
  useEffect(() => {
    const fetchData = async () => {
      const pickupSnapshot = await getDocs(collection(db, "pickupRequests"));
      const schoolSnapshot = await getDocs(collection(db, "schoolDrives"));

      setPickupRequests(pickupSnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
      setSchoolDrives(schoolSnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
    };
    fetchData();
  }, []);

  // Update request status and send email
  const handleRequestAction = async (id, action, email, type) => {
    try {
      const collectionName = type === "pickup" ? "pickupRequests" : "schoolDrives";
      const docRef = doc(db, collectionName, id);

      if (action === "accept") {
        const schedule = prompt("Enter pickup schedule (e.g., 10 AM, 15th Oct):");
        if (schedule) {
          await updateDoc(docRef, { status: "scheduled", schedule });
          sendEmail(email, schedule);
          alert("Pickup scheduled successfully!");

          // Update UI
          if (type === "pickup") {
            setPickupRequests((prev) =>
              prev.map((request) =>
                request.id === id ? { ...request, status: "scheduled", schedule } : request
              )
            );
          } else {
            setSchoolDrives((prev) =>
              prev.map((drive) =>
                drive.id === id ? { ...drive, status: "scheduled", schedule } : drive
              )
            );
          }
        }
      } else if (action === "reject") {
        await updateDoc(docRef, { status: "rejected" });
        alert("Request rejected.");

        // Update UI
        if (type === "pickup") {
          setPickupRequests((prev) =>
            prev.map((request) =>
              request.id === id ? { ...request, status: "rejected" } : request
            )
          );
        } else {
          setSchoolDrives((prev) =>
            prev.map((drive) =>
              drive.id === id ? { ...drive, status: "rejected" } : drive
            )
          );
        }
      }
    } catch (error) {
      console.error("Error updating status: ", error);
    }
  };

  // Send email using EmailJS
  const sendEmail = (email, schedule) => {
    const templateParams = {
      to_email: email,
      schedule,
    };

    emailjs
      .send("service_qidaoub", "template_bxsb8ii", templateParams, "VRqo0Y-Y1chv1IDHc")
      .then((response) => {
        console.log("Email sent:", response);
      })
      .catch((error) => {
        console.error("Email error:", error);
      });
  };

  return (
    <div>
      <h1>Admin Dashboard</h1>

      {/* Pickup Requests */}
      <h2>Pickup Requests</h2>
      <ul>
        {pickupRequests.map((request) => (
          <li key={request.id}>
            <p>User ID: {request.userId}</p>
            <p>Location: {request.pickupLocation}</p>
            <p>Waste Type: {request.wasteType}</p>
            <p>Quantity: {request.quantity}</p>
            <p>Status: {request.status}</p>
            {request.status === "pending" && (
              <>
                <button onClick={() => handleRequestAction(request.id, "accept", request.userId, "pickup")}>
                  Accept
                </button>
                <button onClick={() => handleRequestAction(request.id, "reject", request.userId, "pickup")}>
                  Reject
                </button>
              </>
            )}
            {request.status === "scheduled" && <p>Scheduled: {request.schedule}</p>}
          </li>
        ))}
      </ul>

      {/* School/College Drives */}
      <h2>School/College Drives</h2>
      <ul>
        {schoolDrives.map((drive) => (
          <li key={drive.id}>
            <p>College Name: {drive.collegeName}</p>
            <p>Official Email: {drive.officialEmail}</p>
            <p>Location: {drive.driveLocation}</p>
            <p>Goal: {drive.driveGoal} kg</p>
            <p>Status: {drive.status}</p>
            {drive.status === "pending" && (
              <>
                <button onClick={() => handleRequestAction(drive.id, "accept", drive.officialEmail, "school")}>
                  Accept
                </button>
                <button onClick={() => handleRequestAction(drive.id, "reject", drive.officialEmail, "school")}>
                  Reject
                </button>
              </>
            )}
            {drive.status === "scheduled" && <p>Scheduled: {drive.schedule}</p>}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default AdminDashboard;