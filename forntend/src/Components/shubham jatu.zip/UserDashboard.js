import React, { useState, useEffect } from "react";
import { db, auth } from "../firebaseConfig";
import { collection, addDoc, query, where, getDocs, doc, getDoc, updateDoc, setDoc } from "firebase/firestore";
import { useNavigate } from "react-router-dom";
import emailjs from "emailjs-com";

const UserDashboard = () => {
  const [pickupLocation, setPickupLocation] = useState("");
  const [wasteType, setWasteType] = useState("");
  const [brand, setBrand] = useState("");
  const [model, setModel] = useState("");
  const [quantity, setQuantity] = useState("");
  const [requests, setRequests] = useState([]);
  const [ecoPoints, setEcoPoints] = useState(0);
  const [badges, setBadges] = useState([]);
  const [vouchers, setVouchers] = useState([]);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  // Fetch user data
  useEffect(() => {
    const fetchRequestsAndPoints = async () => {
      const user = auth.currentUser;
      if (user) {
        setUser(user);

        // Fetch Pickup Requests
        const q = query(collection(db, "pickupRequests"), where("userId", "==", user.uid));
        const querySnapshot = await getDocs(q);
        setRequests(querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));

        // Fetch EcoPoints from Firestore
        const userRef = doc(db, "users", user.uid);
        const userSnap = await getDoc(userRef);
        if (userSnap.exists()) {
          setEcoPoints(userSnap.data().points || 0);
          setBadges(userSnap.data().badges || []);
          setVouchers(userSnap.data().vouchers || []);
        } else {
          await setDoc(userRef, { points: 0, badges: [], vouchers: [] });
        }
      }
      setLoading(false);
    };

    fetchRequestsAndPoints();
  }, []);

  // Submit pickup request
  const handleSubmit = async (e) => {
    e.preventDefault();
    const user = auth.currentUser;
    if (!user) {
      alert("Please log in to submit a request.");
      navigate("/login");
      return;
    }

    try {
      // Firestore Submission
      const docRef = await addDoc(collection(db, "pickupRequests"), {
        userId: user.uid,
        pickupLocation,
        wasteType,
        brand,
        model,
        quantity,
        status: "pending",
        createdAt: new Date(),
      });

      // Calculate EcoPoints
      let pointsEarned = 10;
      if (wasteType === "fridge") pointsEarned = 50;
      else if (wasteType === "mobile") pointsEarned = 20;
      else if (wasteType === "tv") pointsEarned = 30;

      await updateEcoPoints(user.uid, pointsEarned);

      // Send Email Notification to Admin
      const emailParams = {
        user_email: "hackonouts@gmail.com",
        message: `New Pickup Request:
                  \nLocation: ${pickupLocation}
                  \nWaste Type: ${wasteType}
                  \nBrand: ${brand}
                  \nModel: ${model}
                  \nQuantity: ${quantity}
                  \nUser ID: ${user.uid}`,
      };

      emailjs.send("service_qidaoub", "template_0gqxc96", emailParams, "user_xxxxxxx");

      alert(`Pickup request submitted successfully! You earned ${pointsEarned} EcoPoints.`);

      // Reset Form Fields
      setPickupLocation("");
      setWasteType("");
      setBrand("");
      setModel("");
      setQuantity("");

      // Refresh Data
      setRequests((prev) => [...prev, { id: docRef.id, pickupLocation, wasteType, brand, model, quantity, status: "pending" }]);
    } catch (error) {
      console.error("Error submitting request:", error);
      alert("An error occurred while submitting the request.");
    }
  };

  // Function to update EcoPoints
  const updateEcoPoints = async (userId, pointsEarned) => {
    const userRef = doc(db, "users", userId);
    try {
      const userSnap = await getDoc(userRef);
      let newPoints = pointsEarned;
      let newBadges = [];
      let newVouchers = [];

      if (userSnap.exists()) {
        newPoints += userSnap.data().points || 0;
        newBadges = checkBadges(newPoints, userSnap.data().badges || []);
        newVouchers = checkVouchers(newPoints, userSnap.data().vouchers || []);
      }

      await updateDoc(userRef, {
        points: newPoints,
        badges: newBadges,
        vouchers: newVouchers,
      });

      setEcoPoints(newPoints);
      setBadges(newBadges);
      setVouchers(newVouchers);
    } catch (error) {
      console.error("Error updating EcoPoints:", error);
    }
  };

  // Function to check and assign badges
  const checkBadges = (points, currentBadges) => {
    const newBadges = [...currentBadges];
    if (points >= 100 && !newBadges.includes("Green Warrior")) newBadges.push("Green Warrior");
    if (points >= 500 && !newBadges.includes("Eco Hero")) newBadges.push("Eco Hero");
    return newBadges;
  };

  // Function to check and assign vouchers
  const checkVouchers = (points, currentVouchers) => {
    const newVouchers = [...currentVouchers];
    if (points >= 200 && !newVouchers.includes("$5 Eco Voucher")) newVouchers.push("$5 Eco Voucher");
    if (points >= 1000 && !newVouchers.includes("$20 Recycling Reward")) newVouchers.push("$20 Recycling Reward");
    return newVouchers;
  };

  return (
    <div>
      <h1>User Dashboard</h1>
      <h2>Pickup System</h2>
      <form onSubmit={handleSubmit}>
        <input type="text" placeholder="Location" value={pickupLocation} onChange={(e) => setPickupLocation(e.target.value)} required />
        <select value={wasteType} onChange={(e) => setWasteType(e.target.value)} required>
          <option value="">Select Waste Type</option>
          <option value="fridge">Fridge</option>
          <option value="mobile">Mobile</option>
          <option value="tv">TV</option>
          <option value="laptop">Laptop</option>
          <option value="batteries">Batteries</option>
        </select>
        <input type="text" placeholder="Brand" value={brand} onChange={(e) => setBrand(e.target.value)} required />
        <input type="text" placeholder="Model" value={model} onChange={(e) => setModel(e.target.value)} required />
        <input type="number" placeholder="Quantity" value={quantity} onChange={(e) => setQuantity(e.target.value)} required />
        <button type="submit">Submit Pickup Request</button>
      </form>

      <h2>Your EcoPoints</h2>
      <p>You have {ecoPoints} EcoPoints.</p>
      <button onClick={() => alert("Feature to redeem vouchers coming soon!")}>Check Available Vouchers</button>

      <h2>Your Pickup Requests</h2>
      <ul>
        {requests.map((request) => (
          <li key={request.id}>
            <p>Location: {request.pickupLocation}</p>
            <p>Waste Type: {request.wasteType}</p>
            <p>Status: {request.status}</p>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default UserDashboard;