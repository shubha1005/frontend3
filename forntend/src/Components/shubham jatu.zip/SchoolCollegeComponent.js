import React, { useState, useEffect } from "react";
import { db, auth } from "../firebaseConfig";
import { 
  collection, 
  addDoc, 
  query, 
  where, 
  getDocs, 
  doc, 
  updateDoc, 
  getDoc 
} from "firebase/firestore";
import { useNavigate } from "react-router-dom";

const SchoolCollegeComponent = () => {
  const [collegeName, setCollegeName] = useState("");
  const [officialEmail, setOfficialEmail] = useState("");
  const [driveLocation, setDriveLocation] = useState("");
  const [driveDate, setDriveDate] = useState("");
  const [driveGoal, setDriveGoal] = useState("");
  const [drives, setDrives] = useState([]);
  const [ecoPoints, setEcoPoints] = useState(0);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  // List of cities in Maharashtra for the dropdown
  const citiesInMaharashtra = [
    "Mumbai",
    "Pune",
    "Nagpur",
    "Nashik",
    "Aurangabad",
    "Solapur",
    "Amravati",
    "Kolhapur",
    "Sangli",
    "Jalgaon",
    "Akola",
    "Latur",
    "Dhule",
    "Ahmednagar",
    "Chandrapur",
    "Parbhani",
    "Beed",
    "Gondia",
    "Yavatmal",
    "Wardha",
    "Buldhana",
    "Hingoli",
    "Washim",
    "Nanded",
    "Satara",
    "Ratnagiri",
    "Sindhudurg",
    "Raigad",
    "Bhandara",
    "Gadchiroli",
    "Nandurbar",
    "Osmanabad",
    "Thane",
  ];

  // Fetch existing drives and EcoPoints
  useEffect(() => {
    const fetchDrivesAndPoints = async () => {
      const user = auth.currentUser;
      if (user) {
        // Fetch Drives
        const q = query(collection(db, "schoolDrives"), where("userId", "==", user.uid));
        const querySnapshot = await getDocs(q);
        setDrives(querySnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));

        // Fetch EcoPoints
        const userRef = doc(db, "users", user.uid);
        const userSnap = await getDoc(userRef);
        if (userSnap.exists()) {
          setEcoPoints(userSnap.data().points || 0);
        }
      }
      setLoading(false);
    };

    fetchDrivesAndPoints();
  }, []);

  // Submit a new drive
  const handleSubmit = async (e) => {
    e.preventDefault();
    const user = auth.currentUser;
    if (!user) {
      alert("Please log in to organize a drive.");
      navigate("/login");
      return;
    }

    try {
      // Add Drive to Firestore
      const docRef = await addDoc(collection(db, "schoolDrives"), {
        userId: user.uid,
        collegeName,
        officialEmail,
        driveLocation,
        driveDate,
        driveGoal,
        status: "pending",
        createdAt: new Date(),
      });

      // Calculate EcoPoints (e.g., 10 points per drive)
      const pointsEarned = 10;
      await updateEcoPoints(user.uid, pointsEarned);

      alert(`Drive organized successfully! You earned ${pointsEarned} EcoPoints.`);

      // Reset Form Fields
      setCollegeName("");
      setOfficialEmail("");
      setDriveLocation("");
      setDriveDate("");
      setDriveGoal("");

      // Refresh Drives List
      setDrives((prev) => [
        ...prev,
        { id: docRef.id, collegeName, officialEmail, driveLocation, driveDate, driveGoal, status: "pending" },
      ]);
    } catch (error) {
      console.error("Error organizing drive:", error);
      alert("An error occurred while organizing the drive.");
    }
  };

  // Function to update EcoPoints
  const updateEcoPoints = async (userId, pointsEarned) => {
    const userRef = doc(db, "users", userId);
    try {
      const userSnap = await getDoc(userRef);
      const newPoints = (userSnap.data().points || 0) + pointsEarned;
      await updateDoc(userRef, { points: newPoints });
      setEcoPoints(newPoints);
    } catch (error) {
      console.error("Error updating EcoPoints:", error);
    }
  };

  if (loading) {
    return <p>Loading...</p>;
  }

  return (
    <div className="p-5">
      <h1 className="text-2xl font-bold text-center">School & College E-Waste Drives</h1>

      {/* Organize a Drive Form */}
      <div className="mt-5">
        <h2 className="text-xl font-semibold">Organize a Drive</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* College Name */}
          <input
            type="text"
            placeholder="College Name"
            value={collegeName}
            onChange={(e) => setCollegeName(e.target.value)}
            required
            className="w-full p-2 border rounded"
          />

          {/* Official Email */}
          <input
            type="email"
            placeholder="Official Email"
            value={officialEmail}
            onChange={(e) => setOfficialEmail(e.target.value)}
            required
            className="w-full p-2 border rounded"
          />

          {/* Location Dropdown */}
          <select
            value={driveLocation}
            onChange={(e) => setDriveLocation(e.target.value)}
            required
            className="w-full p-2 border rounded"
          >
            <option value="">Select Location</option>
            {citiesInMaharashtra.map((city) => (
              <option key={city} value={city}>
                {city}
              </option>
            ))}
          </select>

          {/* Drive Date */}
          <input
            type="date"
            value={driveDate}
            onChange={(e) => setDriveDate(e.target.value)}
            required
            className="w-full p-2 border rounded"
          />

          {/* Drive Goal */}
          <input
            type="number"
            placeholder="Goal (in kg)"
            value={driveGoal}
            onChange={(e) => setDriveGoal(e.target.value)}
            required
            className="w-full p-2 border rounded"
          />

          {/* Submit Button */}
          <button type="submit" className="w-full p-2 bg-green-500 text-white rounded">
            Organize Drive
          </button>
        </form>
      </div>

      {/* Your Drives */}
      <div className="mt-5">
        <h2 className="text-xl font-semibold">Your Drives</h2>
        <ul className="space-y-3">
          {drives.map((drive) => (
            <li key={drive.id} className="p-3 border rounded">
              <p><strong>College Name:</strong> {drive.collegeName}</p>
              <p><strong>Official Email:</strong> {drive.officialEmail}</p>
              <p><strong>Location:</strong> {drive.driveLocation}</p>
              <p><strong>Date:</strong> {new Date(drive.driveDate).toLocaleDateString()}</p>
              <p><strong>Goal:</strong> {drive.driveGoal} kg</p>
              <p><strong>Status:</strong> {drive.status}</p>
            </li>
          ))}
        </ul>
      </div>

      {/* EcoPoints */}
      <div className="mt-5">
        <h2 className="text-xl font-semibold">Your EcoPoints</h2>
        <p>You have <strong>{ecoPoints}</strong> EcoPoints.</p>
        <button
          onClick={() => alert("Feature to redeem vouchers coming soon!")}
          className="mt-2 p-2 bg-blue-500 text-white rounded"
        >
          Check Available Vouchers
        </button>
      </div>
    </div>
  );
};

export default SchoolCollegeComponent;